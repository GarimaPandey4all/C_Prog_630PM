#include <stdio.h>
#include <stdlib.h>

int main()
{
    int num = 5;

    while(num > 0)
    {
        if(num == 2)
            break;

        printf("%d\n", num);
        num--;
    }

    printf("\nNow num is:%d", num);

    return 0;
}
