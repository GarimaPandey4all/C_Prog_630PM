#include <stdio.h>
#include <stdlib.h>

//skip to the next iteration

int main()
{
    int num = 7;

    while(num > 0)
    {
        num--;

        if(num == 5)
            continue;

        printf("%d\n", num);
    }

    return 0;
}
