#include <stdio.h>
#include <stdlib.h>

int main()
{
    int marks[5]; //array with size 5, it stores value from o index to 4 index.
    int i, sum = 0;

    printf("Enter marks:");
    for(i=0; i<5; i++)
    {
        scanf("%d", &marks[i]);
    }

    //printf("First value of array:%d", marks[0]);

    //sum = marks[0] + marks[1] + marks[2] + marks[3] + marks[4];

    //marks[5] = {67, 80, 90, 69, 89};

    //67 + 80

    for(i=0; i<5; i++)
    {
        sum += marks[i]; //assignment operator
    }

    printf("Total Marks: %d.", sum);

    /*
    10 = 0 + 10; //sum =10;
    30 = 10 + 20; // sum = 30;
*/

    return 0;
}
