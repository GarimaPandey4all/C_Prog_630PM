#include <stdio.h>
#include <stdlib.h>

/*
    date, date1, date2

    date = 4, 4, 4

*/

struct Date
{
    int Day; //4bytes
    int Month; //4 bytes
    int Year; //4 bytes
}date, date1, date2;

int main()
{
    //struct Date date, date1, date2;

    date.Day = 2;
    date.Month = 6;
    date.Year = 2020;

    date1.Day = 3;
    date1.Month = 6;
    date1.Year = 2020;

    printf("Today is:%d - %d - %d\n", date.Day, date.Month, date.Year);

    printf("Tommorrow will be: %d %d %d", date1.Day, date1.Month, date1.Year);

    return 0;
}
