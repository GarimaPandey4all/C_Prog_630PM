#include <stdio.h>
#include <stdlib.h>

struct Employee
{
    int ID;
    int age;
    float salary;
};

struct Employee emp1, emp2;

int main()
{
    emp1.age = 25;
    emp1.ID = 001;
    emp1.salary = 13500.15f;

    emp2.age = 27;
    emp2.ID = 124;
    emp2.salary = 34567.89f;

    printf("Employee's Details:\n");
    printf("Employee 1: Id=%d, Age=%d and Salary=%.2f\n", emp1.ID, emp1.age, emp1.salary);
    printf("Employee 2: Id=%d, Age=%d and Salary=%.2f", emp2.ID, emp2.age, emp2.salary);

    return 0;
}
