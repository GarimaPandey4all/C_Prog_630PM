#include <stdio.h>
#include <stdlib.h>

int main()
{
//    int a , b , sum ;
//    scanf("%d",&a);
//    scanf("%d",&b);
//    sum = a + b ;
//    printf("sum is %d\n",sum);

    printf("5+5 = %d\n", 5+5);

    printf("% % % % % \n");

    printf("C" "Programming\n");

    printf("C","Programming\n");

    printf(1+"%d\n");

    printf(1+"%c\n");

    return 0;
}
