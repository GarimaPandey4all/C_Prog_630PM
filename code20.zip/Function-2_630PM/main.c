#include <stdio.h>
#include <stdlib.h>

//Function with arguments and without return value.

void add(int, int); //Function Declaration

int main()
{
    int x, y;
    add(x, y); //function calling
    return 0;
}

//function definition
void add(int a, int b) //Function Prototype
{
    printf("Enter any value for a and b:");
    scanf("%d %d", &a, &b);

    printf("Addition is:%d", a+b);
}
