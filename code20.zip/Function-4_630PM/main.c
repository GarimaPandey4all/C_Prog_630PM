#include <stdio.h>
#include <stdlib.h>

//Function with arguments and with return value.
int add(int, int);

int main()
{
    int x, y, result;
    result = add(x, y);

    printf("Addition is:%d", result);

    return 0;
}

int add(int a, int b)
{

    printf("Enter any value for a and b:");
    scanf("%d %d", &a, &b);

    return a+b;
}

