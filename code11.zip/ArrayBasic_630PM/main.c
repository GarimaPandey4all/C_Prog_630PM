#include <stdio.h>
#include <stdlib.h>

int main()
{
    int array[5] = {10, 20, 50.8, 60, 70};
                    //Traditional way of initialization

    printf("Value at 3rd location in an array is:%f", array[2]);

    int a[5] = {3, 5};

    int b[] = {2,3,4,6,7,8,8,9,99,8,3,3,4,2,6};
                //compile time initialization

    //int b[]; error






    return 0;
}
