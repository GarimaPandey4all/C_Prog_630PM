#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a = 50;

    printf("Value of a is:%d\n", a);

    printf("Address of a is:%d\n", &a); //6422044

    return 0;
}
