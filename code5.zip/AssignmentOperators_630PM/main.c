#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a = 5, c;

    c = a;

    printf("C is: %d\n", c);

    c += a; //c = c + a;

    printf("C is: %d", c);

    c %= a; //c = c % a;

    printf("C is: %d", c);

    return 0;
}
