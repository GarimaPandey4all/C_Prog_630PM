#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a, b, c, Largest;

    printf("Enter value for a , b and c:");
    scanf("%d %d %d", &a, &b, &c);

    if(a>b && a>c)
        printf("A is greater than B and C.");
    else if(b>c)
        printf("B is greater than A and C.");
    else
        printf("C is greater than A and B.");

    return 0;
}
