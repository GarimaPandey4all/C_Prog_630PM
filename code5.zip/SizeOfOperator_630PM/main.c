#include <stdio.h>
#include <stdlib.h>

int main()
{
    printf("Size of Int: %d\n", sizeof(int));
    printf("Size of Float: %d\n", sizeof(float));
    printf("Size of Char: %d\n", sizeof(char));
    printf("Size of Double: %d\n", sizeof(double));
    printf("Size of Long Double: %d\n", sizeof(long double));

    return 0;
}
