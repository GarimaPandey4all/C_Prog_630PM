#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a, b, c, Largest;

    printf("Enter value for a , b and c:");
    scanf("%d %d %d", &a, &b, &c);

    Largest = (a>b) ? ((a>c)? a : c) : ((b>c) ? b : c);

    printf("Largest Number is: %d", Largest);

    return 0;
}
