#include <stdio.h>
#include <stdlib.h>

/*
    Conditional/Ternary Operator:

    Unary- Only 1 Operand
    Binary- Only 2 Operands
    Ternary- Only 3 Operands

    ? : --> Conditional/Ternary

    (expression1) ? (expression2) : (expression3)

    (condition) ? True : False

*/

int main()
{
    int a, b, c;

    printf("Enter value for a and b:");
    scanf("%d %d", &a, &b);

//    c = (a>b) ? a : b;
//
//    printf("Greater value is: %d", c);

    (a>b) ? printf("A is greater than B.") : printf("B is greater than A.");

//    if(a>b)
//    {
//        printf("A is greater than B.") ;
//    }
//    else
//    {
//        printf("B is greater than A.")
//    }

    return 0;
}
