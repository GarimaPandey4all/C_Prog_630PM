#include <iostream>

using namespace std;

int main()
{
    int a, b;
    int choice, number, temp;

    while(1)
    //for(;;)
    {
        printf("\n\nPress 1. Arithmetic Operators.");
        printf("\nPress2. X-OR Bitwise Operator.");
        printf("\nPress3. Even-Odd.");
        printf("\nPress4. Swapping Using Third Variable.");
        printf("\nPress5. Exit.");
        printf("\n\nEnter your choice:");
        scanf("%d", &choice);

        switch(choice)
        {
        case 1:
            printf("Enter value for a and b:");
            scanf("%d %d", &a, &b);

            printf("Addition is:%d.\n", (a+b));

            printf("Subtraction is:%d.\n", (a-b));

            printf("Multiplication is:%d.\n", (a*b));

            printf("Division is:%d.\n", (a/b));

            printf("Modulus is:%d.\n", (a%b));

            printf("Pre-Increment is:%d.\n", ++a);

            printf("Post-Decrement is:%d.\n", b--);

        break;

        case 2:
            printf("Enter value for a and b:");
            scanf("%d %d", &a, &b);

            printf("X-OR is:%d", (a^b));
            break;

        case 3:

            printf("Enter any number:");
            scanf("%d", &number);

            ((number%2)==0) ? printf("Number is Even."): printf("Number is Odd.");
            break;

        case 4:
            printf("Enter value for a and b:");
            scanf("%d %d", &a, &b);

            printf("Before Swapping a= %d and b = %d.", a, b);

            temp = a;
            a = b;
            b = temp;

            printf("After Swapping a= %d and b = %d.", a, b);
            break;
            //break; //exit current condition

        case 5:
            exit(0); //terminate the program

        default:
        printf("Invalid Choice.");
        }
    }

    return 0;
}
