#include <stdio.h>
#include <stdlib.h>

//Write a program which allows user to enter any integer
//until enters a zero


/*
    int n;
    printf("Enter an Integer:");
    scanf("%d", &n);

    while(n != 0)
    {
        printf("Enter an Integer:");
        scanf("%d", &n);
    }

    printf("You are out of the loop.");

*/

int main()
{
    int n;

    do
    {
        printf("Enter an Integer");
        scanf("%d", &n);
    }while(n != 0);

    printf("You are out of the loop.");
    return 0;
}
