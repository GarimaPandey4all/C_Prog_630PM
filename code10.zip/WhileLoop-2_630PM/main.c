#include <stdio.h>
#include <stdlib.h>

int main()
{
    char choice;

    printf("Enter any choice:");
    scanf("%c", &choice);

    //for( ;choice=='y'; )
    while(choice == 'y')
    {
        int number;

        printf("Enter any number:");
        scanf("%d", &number);

        if((number%2)==0)
        {
            printf("Number is Even.\n");
        }
        else
        {
            printf("Number is Odd.\n");
        }

        //choice = 'n';
    }
    return 0;
}
