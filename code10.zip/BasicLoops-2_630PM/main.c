/*

    Loops:

    1. Entry Controlled Loop:
        A loop in which the given condition is checked first,
        before entering into the loop body
    2. Exit Controlled Loop:
        A loop in which the loop body is executed first and then
        after the given condition checked.

    Entry Controlled Loop:
    for
    while

    Exit Controlled Loop:
    Do-While

*/

/*
    Infinite Loop

    while(1) //Always True
    {
        //infinite loop
    }

    for(;;) //Always True
    {
        //Infinite Loop
    }


*/

/*
    for(i=0; i<5; i++)
    {

    }

    i=0;
    while(i<5)
    {
        i++;
    }

    i=1;
    while(i>5)
    {
        printf("Hi");
    }

    for(i=1; i>5;increment/decrement)
    {
        printf("Hi");
    }

*/
