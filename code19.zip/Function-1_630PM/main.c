#include <stdio.h>
#include <stdlib.h>

/*
    Function has four types:

    1. Function without arguments and function without return value.
    2. Function with arguments and without return value.
    3. Function without arguments and with return value.
    4. Function with arguments and with return value.

*/

//Function without arguments and function without return value.

void add(); //Function Declaration

int main()
{
    add(); //Function calling
    return 0;
}

//Function Definition
void add()
{
    int a, b;

    printf("Enter values in a and b:");
    scanf("%d %d", &a, &b);

    printf("Addition is:%d", a+b);
}








