#include <stdio.h>
#include <stdlib.h>

/*
    factorial:

    5! = 5 * 4 * 3 * 2 * 1
*/


int main()
{
    int n, fact = 1, i;

    printf("Enter any number to find factorial:");
    scanf("%d", &n);

    for(i=1; i<=n; i++)
    {
        fact *= i; //fact = fact * i;
    }

    printf("Factorial of a=%d! is %d.", n, fact);

    return 0;
}
