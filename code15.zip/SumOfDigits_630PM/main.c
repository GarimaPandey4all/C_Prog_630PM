#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n, remainder, sum = 0;

    printf("Enter any number:");
    scanf("%d", &n); //n = 121

    while(n > 0)
    {
        remainder = n % 10; // 121 % 10= 1, 2, 1
        sum = sum + remainder; // 1, 3, 4
        n = n / 10; // 121 / 10 = 12, 1
    }

    printf("Sum of digits is:%d", sum);

    return 0;
}
