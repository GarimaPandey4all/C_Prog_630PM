#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n, remainder, reverse = 0;

    printf("Enter any number:");
    scanf("%d", &n); //n = 121

    while(n > 0)
    {
        remainder = n % 10; // 121 % 10= 1, 2, 1
        reverse = reverse * 10 + remainder; // 1, 12, 121
        n = n / 10; // 121 / 10 = 12, 1
    }

    printf("Reverse Number is:%d", reverse);

    return 0;
}
