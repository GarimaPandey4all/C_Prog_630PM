#include <stdio.h>
#include <stdlib.h>

/*
    Fibonacci Series:

    0 1 1 2 3 5 8 13

*/

int main()
{
    int n1 = 0, n2 = 1, n, i, n3;

    printf("Enter number for fibonacci series:");
    scanf("%d", &n);

    printf("Fibonacci Series is:%d %d", n1, n2);

    for(i=2; i<n; i++) //i=2, because n1 and n2 are already printed
    {
        n3 = n1 + n2;
        printf(" %d", n3);

        n1 = n2;
        n2 = n3;
    }




    return 0;
}
