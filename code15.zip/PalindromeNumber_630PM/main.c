#include <stdio.h>
#include <stdlib.h>

/*
    Palindrome Number:

    121 = 121
    131 = 131
    1001 = 1001

*/


int main()
{
    int n, remainder, sum = 0, temp;

    printf("Enter any number to check whether the number is palindrome or not:");
    scanf("%d", &n); //n = 121

    temp = n;

    while(n > 0)
    {
        remainder = n % 10; // 121 % 10= 1, 2, 1
        sum = sum * 10 + remainder; // 1, 12, 121
        n = n / 10; // 121 / 10 = 12, 1
    }

    n = temp;

    if(n == sum)
        printf("Number is Palindrome.");
    else
        printf("Not a Palindrome.");

    return 0;
}
