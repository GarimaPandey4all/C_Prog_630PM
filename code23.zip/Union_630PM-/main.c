#include <stdio.h>
#include <stdlib.h>

union Date
{
    int day;
    int month;
    int year;
}date, date1;

//union Date date;

int main()
{
    //union Date date;

    date.day = 1;

    printf("Day = %d\n", date.day);

    date.month = 10;

    printf("Month = %d\n", date.month);

    date.year = 2020;

    printf("Year = %d\n", date.year);

    //printf("Day = %d Month = %d Year = %d", date.day, date.month, date.year);

    return 0;
}
