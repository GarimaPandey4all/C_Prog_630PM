#include <stdio.h>
#include <stdlib.h>

int main()
{
    //Enum : Enumeration: Group of constants

                //0       1          2         3        4       5         6
    enum Week {Monday, Tuesday, Wednesday = 1, Thursday, Friday, Saturday, Sunday};

    enum Week Today = Monday;

    printf("Today is: %d", Today);

    return 0;
}
