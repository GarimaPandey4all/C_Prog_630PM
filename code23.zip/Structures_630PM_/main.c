#include <stdio.h>
#include <stdlib.h>

struct Date
{
    int day;
    int month;
    int year;
}date, date1;

//struct Date date;

int main()
{
    //struct Date date;

    date.day = 1;
    date.month = 10;
    date.year = 2020;

    printf("Day = %d Month = %d Year = %d", date.day, date.month, date.year);

    return 0;
}
