#include <stdio.h>
#include <stdlib.h> //standard library

int main()
{
    int a;
    float b;

    printf("Enter any value:");
    scanf("%d", &a);

    printf("Enter any value:");
    scanf("%f", &b);

    printf("Entered value of a is:%d\n", a);

    printf("Entered value of b is:%.2f", b);

    getch();

    return 0;
}
