#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a, b, c;

    printf("Enter any value for a:");
    scanf("%d", &a);

    printf("Enter any value for b:");
    scanf("%d", &b);

    c = a/b;

    printf("C is:%d", c);

    return 0;
}
