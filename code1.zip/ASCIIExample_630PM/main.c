#include <stdio.h>
#include <stdlib.h>

int main()
{
    char ch;

    printf("Enter any Character:");
    scanf("%c", &ch);

    printf("Entered character value is: %d", ch);

    return 0;
}
