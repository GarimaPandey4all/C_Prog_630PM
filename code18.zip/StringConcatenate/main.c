#include <stdio.h>
#include <stdlib.h>

int main()
{
    char Firstname[10];
    char Lastname[10];

    printf("Enter your Firstname:");
    gets(Firstname);


    printf("Enter your Lastname:");
    gets(Lastname);

    printf("Your Fullname is: %s", strcat(Firstname, Lastname));

    return 0;
}
