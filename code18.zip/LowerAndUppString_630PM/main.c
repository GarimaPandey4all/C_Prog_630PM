#include <stdio.h>
#include <stdlib.h>

int main()
{
    char str1[10];

    printf("Enter any string:");
    gets(str1);

    printf("Lowercase String: %s\n", strlwr(str1));

    printf("Uppercase String: %s", strupr(str1));
    return 0;
}
