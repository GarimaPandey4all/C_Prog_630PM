/*
    Three types of loops in C.

    1. For Loop
    2. While Loop
    3. Do-While Loop

    1. For Loop

    for(initialization; condition; increment/decrement)
    {
        block of statements
    }

    for(i = 0; i<n; i++)
    {

    }

    2. While Loop

    i=0;
    Initialization

    while(condition) //i<n
    {
        block of statements

        increment/decrement //i++/i--
    }

    3. Do-While Loop

    initialization

    do
    {
        block of statements

        increment/decrement

    }while(condition);

*/


//Loops are not depend upon the arrays but arrays are dependent upon the loops.
