#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a = 4, b = 7;

    //10 = 0000 1010

    //20 = 0001 0100

    //     0000 0000 = 0 //And Operator

    //     0001 1110 = 30 //OR Operator

    printf("Bitwise AND Operator: %d.\n", (a & b)); //0

    printf("Bitwise OR Operator: %d.\n", (a | b)); //30

    return 0;
}
