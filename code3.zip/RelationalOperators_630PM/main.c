#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a, b;

    printf("Enter a value for a:");
    scanf("%d", &a);

    printf("Enter a value for b:");
    scanf("%d", &b);

    if(a == b)
        printf("A is equal to B.\n");

    if(a != b)
        printf("A is not equal to B.\n");

    if(a >= b)
        printf("A is greater than and equal to B.\n");

    if(a <= b)
        printf("A is less than and equal to B.");

    return 0;
}
