#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a, b;

    printf("Enter a value for a:");
    scanf("%d", &a);

    printf("Enter a value for b:");
    scanf("%d", &b);

    if(a && b)
        printf("This is a && b.\n");
    if(a || b)
        printf("This is a || b.\n");
    if(!(a && b))
        printf("This is !(a && b)");

    return 0;
}
