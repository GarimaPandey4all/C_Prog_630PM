#include <stdio.h>
#include <stdlib.h>

//Array - 2D

//Table , Excel Sheet, Matrix

//represent:

/*
    int a[2][3];

    2 rows and 3 columns

    int a[2][3] = {{3, 4, 5}
                  ,{5, 6, 7}};

    int a[2][4][2];

    {}
    {{}}
    {{{}}}

*/


int main()
{
    printf("Hello world!\n");
    return 0;
}
