#include <stdio.h>
#include <stdlib.h>

int main()
{
    int matrix1[5][5], matrix2[5][5], temp[5][5], i, j, rows, columns;

    printf("Enter any number of rows:");
    scanf("%d", &rows);

    printf("Enter any number of columns:");
    scanf("%d", &columns);

    printf("Enter %d values in matrix 1:\n", rows*columns);
    for(i=0; i<rows; i++)
    {
        for(j=0; j<columns; j++)
        {
            scanf("%d", &matrix1[i][j]);
        }
    }


    printf("Enter %d values in matrix 2:\n", rows*columns);
    for(i=0; i<rows; i++)
    {
        for(j=0; j<columns; j++)
        {
            scanf("%d", &matrix2[i][j]);
        }
    }

    printf("Values in matrix 1 are:\n");
    for(i=0; i<rows; i++)
    {
        for(j=0; j<columns; j++)
        {
            printf("%d\t", matrix1[i][j]);
        }
        printf("\n");
    }

    printf("Values in matrix 2 are:\n");
    for(i=0; i<rows; i++)
    {
        for(j=0; j<columns; j++)
        {
            printf("%d\t", matrix2[i][j]);
        }
        printf("\n");
    }

    for(i=0; i<rows; i++)
    {
        for(j=0; j<columns; j++)
        {
            temp[i][j] = matrix1[i][j] + matrix2[i][j];
        }
    }

    printf("Addition of two matrices are:\n");
    for(i=0; i<rows; i++)
    {
        for(j=0; j<columns; j++)
        {
            printf("%d\t", temp[i][j]);
        }
        printf("\n");
    }

    return 0;
}
