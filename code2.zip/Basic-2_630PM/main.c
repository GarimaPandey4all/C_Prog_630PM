#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a = 45, b = 5.5;
    float sum;

    sum = a + b; //45 + 5= 50

    //sum = 50.000000;

    return 0;
}
