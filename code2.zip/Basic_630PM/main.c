#include <stdio.h>
#include <stdlib.h>

int main()
{
    char ch;

    printf("Hello, How are you?");
    scanf("%c", &ch);

    return 0;
}
