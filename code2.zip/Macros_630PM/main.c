#include <stdio.h>
#include <stdlib.h>
#define MONTHS 12 //Macros
#define PI 3.14

//Macros
int main()
{
    int r = 5;
    float area;

    printf("1 Year = %d Months.\n", MONTHS);
    printf("Months = %d.\n", MONTHS);

    area = PI * r * r;

    printf("Area of a circle is:%f", area);

    return 0;
}
