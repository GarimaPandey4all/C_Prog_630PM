#include <stdio.h>
#include <stdlib.h>

int main()
{
    //int a;  // variable declaration

    int a = 123; //Variable declaration and initialization //4 bytes

    const float b = 10.2; //4 bytes //now b is fixed

    double c = 123.67; //8 bytes

    char d = 'A'; // 1byte

    a = 20; // a is re-initialize

    printf("A is : %d", a);

   // b = 20.5; //error

    return 0;
}
