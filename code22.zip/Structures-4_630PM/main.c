#include <stdio.h>
#include <stdlib.h>

struct Employee
{
    int id;
    char name[10];
    int contact;
    char address[15];
    int DOJ;
};

int main()
{
    struct Employee Emp[5];
    int i;

    for(i=0; i<5; i++)
    {
        printf("Enter your name:\n");
        scanf("%s", Emp[i].name);
        printf("Enter your Id:\n");
        scanf("%d", &Emp[i].id);
    }

    printf("Employee's Details:\n\n");
    for(i=0; i<5; i++)
    {
        printf("Employee %d name:%s\n", i+1, Emp[i].name);
        printf("Employee %d Id:%d\n\n", i+1, Emp[i].id);
    }

    return 0;
}
