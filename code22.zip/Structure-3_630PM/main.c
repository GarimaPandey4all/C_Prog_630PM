#include <stdio.h>
#include <stdlib.h>

struct Student
{
    int age;
    char gender;
    char name[10];
    char dept[10];
    char email[15];
};

int main()
{
    struct Student S1;

    S1.age = 18;

    S1.gender = 'M';

    strcpy(S1.name, "Amanpreet");

    strcpy(S1.dept, "12A");

    strcpy(S1.email, "aman@gmail.com");


    printf("Student Age is:%d\n", S1.age);
    printf("Student Gender is:%c\n", S1.gender);
    //printf("Student Name is:%s\n", S1.name);
    printf("Student Dept is:%s\n", S1.dept);
    printf("Student Email is:%s\n", S1.email);

//    printf("Enter your name");
//    scanf("%s\n", S1.name);

    printf("Student Name is:%s\n", S1.name);

    return 0;
}
