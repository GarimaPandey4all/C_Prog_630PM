#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i, j;

    for(i=101; i>=97; i--) //outer loop
    {
        for(j=i; j>=97; j--) //inner loop
        {
            //printf("%c", i);
            printf("%c", j);
        }
        printf("\n");
    }
    return 0;
}
