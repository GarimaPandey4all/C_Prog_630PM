#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i, j;

    for(i=69; i>=65; i--) //outer loop
    {
        for(j=i; j>=65; j--) //inner loop
        {
            printf("%c", i);
            //printf("%c", j);
        }
        printf("\n");
    }
    return 0;
}
