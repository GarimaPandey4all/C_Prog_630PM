#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i, j;

    for(i=97; i<=101; i++) //outer loop
    {
        for(j=97; j<=101; j++) //inner loop
        {
            //printf("%c", i);
            printf("%c", j);
        }
        printf("\n");
    }


    return 0;
}
