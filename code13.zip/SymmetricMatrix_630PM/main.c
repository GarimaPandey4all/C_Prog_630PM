#include <stdio.h>
#include <stdlib.h>

int main()
{
    int matrix[5][5], i, j, rows, columns, temp[5][5], count = 1;

    printf("Enter any number of rows:");
    scanf("%d", &rows);

    printf("Enter any number of colums:");
    scanf("%d", &columns);

    printf("Enter %d Values:", rows*columns);
    for(i=0; i<rows; i++)
    {
        for(j=0; j<columns; j++)
        {
            scanf("%d", &matrix[i][j]);
        }
    }

    printf("Values in Matrix:\n");
    for(i=0; i<rows; i++)
    {
        for(j=0; j<columns; j++)
        {
            printf("%d\t", matrix[i][j]);
        }
        printf("\n");
    }

    //Transpose of a matrix
    for(i=0; i<rows; i++)
    {
        for(j=0; j<columns; j++)
        {
            temp[j][i] = matrix[i][j];
        }
    }

    printf("Transpose matrix is:\n");
    for(i=0; i<rows; i++)
    {
        for(j=0; j<columns; j++)
        {
            printf("%d\t", temp[i][j]);
        }
        printf("\n");
    }

    //Logic to check for symmetric matrix using count keyword
    for(i=0; i<rows; i++)
    {
        for(j=0; j<columns; j++)
        {
            if(matrix[i][j] != temp[i][j])
            {
                ++count;
                break;
            }
        }
    }

    if(count == 1)
        printf("Symmetric Matrix.");
    else
        printf("Not a Symmetric Matrix.");

    return 0;
}
