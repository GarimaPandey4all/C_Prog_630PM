#include <stdio.h>
#include <stdlib.h>

int main()
{
    int matrix[5][5], i, j, rows, columns, total = 0;

    printf("Enter any number of rows:");
    scanf("%d", &rows);

    printf("Enter any number of colums:");
    scanf("%d", &columns);

    printf("Enter %d Values:", rows*columns);
    for(i=0; i<rows; i++)
    {
        for(j=0; j<columns; j++)
        {
            scanf("%d", &matrix[i][j]);
        }
    }

    printf("Values in Matrix:\n");
    for(i=0; i<rows; i++)
    {
        for(j=0; j<columns; j++)
        {
            printf("%d\t", matrix[i][j]);
        }
        printf("\n");
    }

    //Logic for find the total count of zeroes
    for(i=0; i<rows; i++)
    {
        for(j=0; j<columns; j++)
        {
            if(matrix[i][j] == 0)
            {
                ++total;
            }
        }
    }

    //Total no of zeroes > No of nonzeroes
    if(total> (rows*columns)/2)
        printf("Sparse Matrix.");
    else
        printf("Not a sparse matrix.");

    return 0;
}
