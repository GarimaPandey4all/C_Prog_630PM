#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i, j, n;

    printf("Enter number of rows that you want to print pyramid:");
    scanf("%d", &n);

    for(i=1; i<=n; i++)
    {
        for(j=1; j<= 2 * n - 1; j++)
        {
            //1 >= 3
            if(j >= n-(i-1) && j <= n+(i-1))
            {
                printf("*");
            }
            else
                printf(" ");
        }
        printf("\n");
    }

    return 0;
}

