#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*
    character of arrays is called string in c.

*/

int main()
{
    char name[10];

    printf("Enter your name:");
    gets(name); //read string input
    //scanf("%s", &name);

    //puts(name);
    printf("Your name is:%s", name);

    return 0;
}
