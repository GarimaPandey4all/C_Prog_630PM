#include <stdio.h>
#include <stdlib.h>

/*
    string prebuild functions:

    1. string length
    2. string copy
    3. string concatenation
    4. string compare
    5. string lowercase / uppercase
*/


int main()
{
    char name[10];

    printf("Enter your name:");
    gets(name);

    printf("Your name's length is:%d", strlen(name));

    return 0;
}
