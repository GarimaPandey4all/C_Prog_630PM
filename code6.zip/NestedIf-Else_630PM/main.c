#include <stdio.h>
#include <stdlib.h>

//Nested If-ELse

int main()
{
    int number;

    printf("Enter any number:");
    scanf("%d", &number);

    if(number > -1)
    {
        if((number % 2) == 0 )
            printf("Number is Even.");
        else
            printf("Number is Odd.");
    }
    else
        printf("Invalid Number.");

    return 0;
}
