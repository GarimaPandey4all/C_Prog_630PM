#include <stdio.h>

int main()
{
    char var = 7;

    printf("Left Shift is:%d\n", var<<1); //14

    printf("Right Shift is: %d", var>>1); //3
}
