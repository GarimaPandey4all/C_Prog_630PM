#include <stdio.h>
#include <stdlib.h>

int main()
{
    char a = 4, b= 5;
    //0100 =4
    //0101 =5

    //Swapping without using third variable

    printf("Before X-OR the value of a=%d and b=%d.\n", a, b);

    a = a ^ b; //0100 ^ 0101 = 0001 =1
    b = a ^ b; //0001 ^ 0101 = 0100 =4
    a = a ^ b; //0001 ^ 0100 = 0101 =5

    printf("After X-OR the value of a=%d and b=%d.", a, b);

    return 0;
}
