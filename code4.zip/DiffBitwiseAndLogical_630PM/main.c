#include <stdio.h>
#include <stdlib.h>

int main()
{
    char x = 1, y = 2;

    //1 = 0000 0001
    //2 = 0000 0010
    //    0000 0000= 0 = 1&2

    //1 && 2 = true && true = true

    if(x & y) //0000 0001 & 0000 0010 = 0
        printf("Result is x & y.");
    if(x && y) // true && true = true
        printf("Result is x && y.");

    return 0;
}
