#include <stdio.h>
#include <stdlib.h>

int main()
{
    char a = 4, b = 5;

    printf("Before Swapping the value of a=%d and b=%d.\n", a, b);

    //First Way: + and -

//    a = a + b; //9
//    b = a - b; //4
//    a = a - b; //5
//
//    printf("After Swapping the value of a=%d and b=%d.", a, b);

    //Second Way: * and /

    a = a * b; //20
    b = a / b; //4
    a = a / b; //5

    printf("After Swapping the value of a=%d and b=%d.", a, b);

    return 0;
}
