#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a = 4, b = 5, temp;

    printf("Before Swapping the value of a=%d and b=%d.\n", a, b);

    temp = a;
    a = b;
    b = temp;

    printf("After Swapping the value of a=%d and b=%d.", a, b);

    return 0;
}
