#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    int value, squareRoot;

    printf("Enter any value:");
    scanf("%d", &value);

    squareRoot = sqrt(value);

    printf("SquareRoot is:%d", squareRoot);

    return 0;
}
