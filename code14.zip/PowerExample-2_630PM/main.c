#include <stdio.h>
#include <stdlib.h>
#include <math.h>


int main()
{
     int base, exponent, result;

    printf("Enter base:");
    scanf("%d", &base);

    printf("Enter exponent:");
    scanf("%d", &exponent);

    result = pow(base, exponent);

    printf("Base = %d, Exponent = %d and\n\n The Power of it is: %d.", base, exponent, result);

    return 0;
}
