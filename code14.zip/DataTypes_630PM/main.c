#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a;
    int b;

    printf("Enter any value for a:");
    scanf("%2d", &a);

//    printf("Enter any value for b:");
//    scanf("%2d", &b);

    printf("Value of a=%2d.\n", a);

    printf("Enter any value for b:\n");
    scanf("%2d", &b);

    printf("\nValue of b=%2d.", b);


    //printf("Value of a=%2d and b=%.2f.", a, b);

    return 0;
}
