#include <stdio.h>
#include <stdlib.h>

/*
    power = base ^ Exponent

    power = 2 ^ 5 = 32

*/


int main()
{
    int base, exponent, power = 1, temp;

    printf("Enter base:");
    scanf("%d", &base);

    printf("Enter exponent:");
    scanf("%d", &exponent);

    temp = exponent;

    while(exponent != 0) //5, 4, 3, 2, 1, 0=false
    {
        power *= base; //power = power * base;
        --exponent;
    }

    exponent = temp;

    printf("Base = %d, Exponent = %d and the Power of it is: %d.", base, exponent, power);

    return 0;
}
