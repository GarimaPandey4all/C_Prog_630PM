#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a, b, c;

    printf("Enter value for a, b, and c:");
    scanf("%d %d %d", &a, &b, &c);

    if(a == b && b==c)
        printf("Equilateral Triangle.");
    else if(a==b || a==c || b==c)
        printf("Isosceles Triangle.");
    else
        printf("Scalane Triangle.");

    return 0;
}

