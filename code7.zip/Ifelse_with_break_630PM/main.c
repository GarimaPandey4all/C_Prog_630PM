#include <stdio.h>
#include <stdlib.h>

int main()
{
    int number=3;

    if((number%2)==0)
    {
        printf("Number is even.\n");
    }
    else
    {
        printf("Number is Odd.\n");
        exit(0); //terminate the program and use 0 value in there argument value, zero is equivalent to void
    }

    printf("Number is:%d.", number);

    return 0;
}
