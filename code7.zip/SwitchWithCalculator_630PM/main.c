#include <stdio.h>
#include <stdlib.h>

int main()
{
    char Operator;
    int a, b;

    printf("Enter any operator:");
    scanf("%c", &Operator);

    switch(Operator)
    {
    case '+':
        printf("Enter value for a:");
        scanf("%d", &a);

        printf("Enter value for b:");
        scanf("%d", &b);

        printf("Addition is:%d.", (a+b));
        break;

    case '-':
        printf("Enter value for a:");
        scanf("%d", &a);

        printf("Enter value for b:");
        scanf("%d", &b);

        printf("Subtraction is:%d.", (a-b));
        break;

    case '*':
        printf("Enter value for a:");
        scanf("%d", &a);

        printf("Enter value for b:");
        scanf("%d", &b);

        printf("Multiplication is:%d.", (a*b));
        break;

    case '/':
        printf("Enter value for a:");
        scanf("%d", &a);

        printf("Enter value for b:");
        scanf("%d", &b);

        printf("Division is: %d.", (a/b));
        break;

    default:
        printf("Invalid operator.");
        //break;
    }

    return 0;
}
